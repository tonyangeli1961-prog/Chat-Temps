# Trailer Temperature V3 — Production Deployment

## Target
Railway + PostgreSQL + HTTPS + Android client + browser admin portal.

### 1. Railway services
Create:
1. PostgreSQL service
2. API service from `server/`
3. Optional backup worker service using `backup-Dockerfile`

Railway's PostgreSQL service exposes `DATABASE_URL` and other connection variables to services in the project. Use the managed PostgreSQL service rather than running Postgres in Docker.

### 2. Secure secrets
Set these in Railway service variables:
- JWT_SECRET: 64+ random characters
- ADMIN_USERNAME: your chosen administrator username
- ADMIN_PASSWORD: a unique strong password
- ADMIN_INITIALS: administrator initials
- CORS_ORIGIN: the exact HTTPS admin origin when known
- PGSSL=true

Do not commit secrets into Git.

### 3. HTTPS
Add a Railway-generated domain or custom domain to the API service and use its HTTPS URL in the Android app. Do not use an HTTP production endpoint.

### 4. PostgreSQL backups
Enable Railway scheduled backups (daily/weekly/monthly as appropriate). For stronger disaster recovery, also run logical `pg_dump` backups to storage outside the primary project and periodically perform a restore drill.

### 5. Android
Configure the app's API base URL to the HTTPS API domain. Production Android networking should reject cleartext HTTP.

### 6. Admin portal
The API serves `/` as the web administrator dashboard. It provides:
- Inspection counts
- Out-of-range counts
- Today's inspection count
- Inspection history
- Excel export
- Operator account creation
- Operator enable/disable
- Fixed temperature standards

### 7. Temperature rules
These are fixed in both client/server reporting logic:
- Freezer: -10°F through 10°F
- Cooler: 34°F through 40°F

### 8. Operational security
Before going live:
- Change the initial admin password.
- Use HTTPS only.
- Keep database private to the Railway project.
- Limit CORS to the real admin origin.
- Keep backups and test restores.
- Monitor `/api/health`.
- Rotate JWT secrets only with a planned token/session transition.
