let token=localStorage.getItem("tt_token");
const $=id=>document.getElementById(id);
function headers(){return {"Authorization":"Bearer "+token,"Content-Type":"application/json"}}
async function login(){
 const r=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:$("u").value,password:$("p").value})});
 if(!r.ok){$("lm").textContent="Invalid username or password";return}
 const x=await r.json();token=x.token;localStorage.setItem("tt_token",token);show();
}
function logout(){localStorage.removeItem("tt_token");token=null;location.reload()}
async function load(){
 const [a,b]=await Promise.all([fetch("/api/records",{headers:headers()}),fetch("/api/operators",{headers:headers()})]);
 if(!a.ok||!b.ok){logout();return}
 const rec=await a.json(),ops=await b.json(),now=new Date();let bad=0,today=0;
 $("rows").innerHTML=rec.map(x=>{
   const d=new Date(Number(x.timestamp_utc));const out=!(Number(x.freezer_f)>=-10&&Number(x.freezer_f)<=10&&Number(x.cooler_f)>=34&&Number(x.cooler_f)<=40);
   if(out)bad++;if(d.toDateString()===now.toDateString())today++;
   return `<tr><td>${d.toLocaleString()}</td><td>${esc(x.trailer_number)}</td><td>${x.freezer_f}°F</td><td>${x.cooler_f}°F</td><td class="${out?'bad':'ok'}">${out?'OUT OF RANGE':'OK'}</td><td>${esc(x.operator_initials)}</td></tr>`
 }).join("");
 $("orows").innerHTML=ops.map(x=>`<tr><td>${esc(x.username)}</td><td>${esc(x.initials)}</td><td>${x.role}</td><td>${x.active?'Yes':'No'}</td><td><button onclick="toggleOp(${x.id},${!x.active})">${x.active?'Disable':'Enable'}</button></td></tr>`).join("");
 $("total").textContent=rec.length;$("bad").textContent=bad;$("today").textContent=today;$("ops").textContent=ops.length;
}
async function addOp(){
 const body={username:$("nu").value,password:$("np").value,initials:$("ni").value,role:$("nr").value};
 const r=await fetch("/api/operators",{method:"POST",headers:headers(),body:JSON.stringify(body)});
 if(!r.ok){alert((await r.json()).error||"Could not create");return}
 $("nu").value=$("np").value=$("ni").value="";load();
}
async function toggleOp(id,active){await fetch("/api/operators/"+id,{method:"PATCH",headers:headers(),body:JSON.stringify({active})});load()}
async function downloadXlsx(){
 const r=await fetch("/api/export.xlsx",{headers:headers()});if(!r.ok){alert("Export failed");return}
 const blob=await r.blob(),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="trailer-temperature-inspections.xlsx";a.click();URL.revokeObjectURL(a.href)
}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function show(){$("login").hidden=true;$("app").hidden=false;load()}
if(token)show();
